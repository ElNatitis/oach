#include <math.h>

double beta(z,w)
double z,w;
{
	double gammln();

	return exp(gammln(z)+gammln(w)-gammln(z+w));
}
