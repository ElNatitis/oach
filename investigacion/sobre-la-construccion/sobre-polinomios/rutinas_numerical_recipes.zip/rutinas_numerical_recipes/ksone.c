#include <math.h>

static double maxarg1,maxarg2;
#define MAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
	(maxarg1) : (maxarg2))

void ksone(data,n,func,d,prob)
double data[],*d,*prob;
double (*func)();	/* ANSI: double (*func)(double); */
int n;
{
	int j;
	double fo=0.0,fn,ff,en,dt;
	void sort();
	double probks();

	sort(n,data);
	en=n;
	*d=0.0;
	for (j=1;j<=n;j++) {
		fn=j/en;
		ff=(*func)(data[j]);
		dt = MAX(fabs(fo-ff),fabs(fn-ff));
		if (dt > *d) *d=dt;
		fo=fn;
	}
	en = sqrt(en);
	*prob=probks((en+0.12+0.11/en)*(*d));
}

#undef MAX
