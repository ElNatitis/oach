static double xsav,ysav;
static double (*nrfunc)(); /* ANSI: static double (*nrfunc)(double,double,double); */

double quad3d(func,x1,x2)
double x1,x2,(*func)();
{
	double qgaus(),f1();

	nrfunc=func;
	return qgaus(f1,x1,x2);
}

double f1(x)
double x;
{
	double qgaus(),f2();
	double yy1(),yy2();	/* ANSI: double yy1(double),yy2(double); */

	xsav=x;
	return qgaus(f2,yy1(x),yy2(x));
}

double f2(y)
double y;
{
	double qgaus(),f3();
	double z1(),z2(); /* ANSI: double z1(double,double),z2(double,double); */

	ysav=y;
	return qgaus(f3,z1(xsav,y),z2(xsav,y));
}

double f3(z)
double z;
{
	return (*nrfunc)(xsav,ysav,z);
}
