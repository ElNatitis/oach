#include <math.h>

double bico(n,k)
int n,k;
{
	double factln();

	return floor(0.5+exp(factln(n)-factln(k)-factln(n-k)));
}
