#define FUNC(x) ((*func)(x))

double midpnt(func,a,b,n)
double a,b;
int n;
double (*func)();	/* ANSI: double (*func)(double); */
{
	double x,tnm,sum,del,ddel;
	static double s;
	static int it;
	int j;

	if (n == 1) {
		it=1;
		return (s=(b-a)*FUNC(0.5*(a+b)));
	} else {
		tnm=it;
		del=(b-a)/(3.0*tnm);
		ddel=del+del;
		x=a+0.5*del;
		sum=0.0;
		for (j=1;j<=it;j++) {
			sum += FUNC(x);
			x += ddel;
			sum += FUNC(x);
			x += del;
		}
		it *= 3;
		s=(s+(b-a)*sum/tnm)/3.0;
		return s;
	}
}

#undef FUNC
