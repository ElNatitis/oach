extern int ncom;	/* defined in DLINMIN */
extern double *pcom,*xicom,(*nrfunc)();
extern void (*nrdfun)();

double df1dim(x)
double x;
{
	int j;
	double df1=0.0;
	double *xt,*df,*vector();
	void free_vector();

	xt=vector(1,ncom);
	df=vector(1,ncom);
	for (j=1;j<=ncom;j++) xt[j]=pcom[j]+x*xicom[j];
	(*nrdfun)(xt,df);
	for (j=1;j<=ncom;j++) df1 += df[j]*xicom[j];
	free_vector(df,1,ncom);
	free_vector(xt,1,ncom);
	return df1;
}
