#include <math.h>

double expdev(idum)
int *idum;
{
	double ran1();

	return -log(ran1(idum));
}
